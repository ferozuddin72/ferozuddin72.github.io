jQuery( function() {
	
	// For Wow Effect
	wow = new WOW({
		boxClass: 'freesia-animation'
		});
	wow.init();

} );